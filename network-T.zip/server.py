import socket
import threading
from datetime import datetime

HOST = '127.0.0.1'  # localhost
PORT = 12345        # designated port

# لیست کلاینت‌های متصل و نگهداری نام کاربری هر کدام
clients = []              # list of client sockets
clients_info = {}         # dictionary mapping client_socket to username

def broadcast(message, sender_socket):
    """Send message to all clients except the sender."""
    for client in clients:
        if client != sender_socket:
            try:
                client.sendall(message)
            except Exception as e:
                print(f"[!] Error broadcasting to a client: {e}")
                client.close()
                if client in clients:
                    clients.remove(client)
                if client in clients_info:
                    del clients_info[client]

def handle_client(client_socket, client_address):
    try:
        # درخواست نام کاربری از کلاینت
        client_socket.sendall("Enter your username:".encode())
        username = client_socket.recv(1024).decode().strip()
        if not username:
            client_socket.close()
            return
        clients_info[client_socket] = username
        print(f"[+] {username} ({client_address[0]}) connected.")
        broadcast(f"[+] {username} ({client_address[0]}) joined the chat.".encode(), client_socket)

        while True:
            message = client_socket.recv(1024)
            if not message:
                break
            decoded = message.decode().strip()
            # چک کردن دستور خروج
            if decoded == "exit/":
                print(f"[-] {username} ({client_address[0]}) sent exit command.")
                break

            # بررسی پیام خصوصی (فرمت: <pm recipient message>)
            if decoded.startswith("<pm"):
                parts = decoded.split(" ", 2)  # باید شامل 3 بخش باشد
                if len(parts) < 3:
                    client_socket.sendall("Invalid private message format. Use: <pm recipient message".encode())
                else:
                    _, recipient, private_msg = parts
                    found = False
                    for sock, user in clients_info.items():
                        if user == recipient:
                            timestamp = datetime.now().strftime("%H:%M:%S")
                            pm_message = f"[PM][{timestamp}] {username}: {private_msg}"
                            sock.sendall(pm_message.encode())
                            found = True
                            break
                    if not found:
                        client_socket.sendall(f"User '{recipient}' not found.".encode())
            else:
                # پیام عمومی: افزودن زمان ارسال به پیام
                timestamp = datetime.now().strftime("%H:%M:%S")
                full_message = f"[{timestamp}] {username}: {decoded}"
                broadcast(full_message.encode(), client_socket)
                # همچنین ارسال خود پیام به فرستنده (برای نمایش در UI)
                client_socket.sendall(full_message.encode())
    except Exception as e:
        print(f"[!] Error with {client_address} ({clients_info.get(client_socket, 'Unknown')}): {e}")
    finally:
        client_socket.close()
        if client_socket in clients:
            clients.remove(client_socket)
        left_username = clients_info.get(client_socket, "Unknown")
        if client_socket in clients_info:
            del clients_info[client_socket]
        broadcast(f"[-] {left_username} has left the chat.".encode(), client_socket)
        print(f"[-] Connection with {client_address} closed.")

def start_server():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind((HOST, PORT))
    server_socket.listen()
    print(f"[+] Server listening on {HOST}:{PORT}...")

    while True:
        client_socket, client_address = server_socket.accept()
        clients.append(client_socket)
        client_thread = threading.Thread(target=handle_client, args=(client_socket, client_address))
        client_thread.start()

if __name__ == "__main__":
    start_server()
