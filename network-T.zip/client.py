import socket
import threading
import tkinter as tk
from tkinter import scrolledtext, messagebox, simpledialog
from datetime import datetime

HOST = '127.0.0.1'  # server address
PORT = 12345        # same as server's port

class ChatClient:
    def __init__(self, master):
        self.master = master
        master.title("Chat Client")
        
        # تنظیم رابط کاربری
        self.chat_area = scrolledtext.ScrolledText(master, wrap=tk.WORD, state='disabled', width=50, height=20)
        self.chat_area.pack(padx=10, pady=10)
        
        self.msg_entry = tk.Entry(master, width=40)
        self.msg_entry.pack(side=tk.LEFT, padx=(10,0), pady=(0,10))
        self.msg_entry.bind("<Return>", self.send_message)
        
        self.send_button = tk.Button(master, text="Send", command=self.send_message)
        self.send_button.pack(side=tk.LEFT, padx=(5,10), pady=(0,10))
        
        self.client_socket = None
        self.username = None
        
        self.connect_to_server()

    def connect_to_server(self):
        try:
            self.client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.client_socket.connect((HOST, PORT))
            
            # دریافت درخواست نام کاربری از سرور
            prompt = self.client_socket.recv(1024).decode()
            self.prompt_username(prompt)
            
            # شروع دریافت پیام‌ها در یک thread جداگانه
            threading.Thread(target=self.receive_messages, daemon=True).start()
        except Exception as e:
            messagebox.showerror("Connection Error", f"Unable to connect to server: {e}")
            self.master.destroy()

    def prompt_username(self, prompt):
        self.username = simpledialog.askstring("Username", prompt)
        if not self.username:
            messagebox.showerror("Error", "Username cannot be empty!")
            self.master.destroy()
        else:
            self.client_socket.sendall(self.username.encode())
            self.display_message(f"Connected as {self.username}")

    def receive_messages(self):
        while True:
            try:
                message = self.client_socket.recv(1024).decode()
                if not message:
                    self.display_message("Connection closed by the server.")
                    break
                self.display_message(message)
            except Exception as e:
                self.display_message(f"[!] Error receiving message: {e}")
                break

    def send_message(self, event=None):
        message = self.msg_entry.get().strip()
        if message == "":
            return
        try:
            self.client_socket.sendall(message.encode())
            # در صورت ارسال دستور خروج، اتصال بسته شود
            if message == "exit/":
                self.client_socket.close()
                self.master.destroy()
        except Exception as e:
            self.display_message(f"[!] Error sending message: {e}")
        self.msg_entry.delete(0, tk.END)
    
    def display_message(self, message):
        # نمایش پیام همراه با زمان محلی دریافت در رابط کاربری
        self.chat_area.config(state='normal')
        self.chat_area.insert(tk.END, message + "\n")
        self.chat_area.config(state='disabled')
        self.chat_area.see(tk.END)

if __name__ == "__main__":
    root = tk.Tk()
    client = ChatClient(root)
    root.mainloop()
